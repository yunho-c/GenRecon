#dram = #ttnn.buffer_type<dram>
#loc1 = loc("x")
#loc2 = loc("y")
#system_desc = #ttcore.system_desc<[{role = host, target_triple = "x86_64-pc-linux"}], [{arch = <wormhole_b0>, grid = 8x8, coord_translation_offsets = 18x18, l1_size = 1499136, num_dram_channels = 12, dram_channel_size = 1073741824, noc_l1_address_align_bytes = 16, pcie_address_align_bytes = 32, noc_dram_address_align_bytes = 32, l1_unreserved_base = 105536, erisc_l1_unreserved_base = 98304, dram_unreserved_base = 1048640, dram_unreserved_end = 1073108608, supported_data_types = [<f32>, <f16>, <bf16>, <bfp_f8>, <bfp_bf8>, <bfp_f4>, <bfp_bf4>, <bfp_f2>, <bfp_bf2>, <u32>, <u16>, <u8>, <si32>], supported_tile_sizes = [ 4x16,  16x16,  32x16,  4x32,  16x32,  32x32], dst_physical_size_tiles = 16, num_cbs = 64, num_compute_threads = 1, num_datamovement_threads = 2, dram_grid = 1x12, dram_bank_to_logical_worker_noc0 = [(7, 3), (0, 0), (4, 0), (5, 0), (0, 4), (3, 7), (1, 4), (7, 4), (6, 4), (2, 4), (4, 4), (5, 4)], dram_bank_to_logical_worker_noc1 = [(7, 3), (0, 0), (4, 0), (5, 0), (0, 4), (3, 7), (1, 4), (7, 4), (6, 4), (2, 4), (4, 4), (5, 4)]}], [0], [1 : i32], [ 0x0x0x0]>
#ttnn_layout = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<512x128xbf16, #dram>, <interleaved>>
#ttnn_layout1 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<128x512xbf16, #dram>, <interleaved>>
#ttnn_layout2 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<16x16x!ttcore.tile<32x32, f32>, #dram>, <interleaved>>
#ttnn_layout3 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<16x4x!ttcore.tile<32x32, bf16>, #dram>, <interleaved>>
#ttnn_layout4 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<4x16x!ttcore.tile<32x32, bf16>, #dram>, <interleaved>>
module @jit_dot attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32, ttcore.meshes = #ttcore.meshes<[<"empty_mesh" = 1x1>]>} {
  ttcore.device_module {
    builtin.module @jit_dot attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32, ttcore.meshes = #ttcore.meshes<[<"empty_mesh" = 1x1>]>, ttcore.system_desc = #system_desc, ttnn.l1_const_eval_usage = 1024 : ui64} {
      ttcore.device @default_device = <workerGrid = #ttcore.grid<8x8, virt_to_physical_map = (d0, d1) -> (0, d0, d1), physical_to_virt_map = (d0, d1, d2) -> (d1, d2)>, dramGrid = #ttcore.grid<1x12>, l1Map = (d0, d1, d2)[s0] -> (0, d0, d1, d2 + s0), dramMap = (d0, d1, d2)[s0, s1, s2, s3, s4, s5, s6] -> (0, 0, (((d0 * s1) * (s2 * (s3 * s6)) + d1 * (s2 * (s3 * s6)) + d2) floordiv s4) mod 12, ((((d0 * s1) * (s2 * (s3 * s6)) + d1 * (s2 * (s3 * s6)) + d2) floordiv s4) floordiv 12) * s4 + ((d0 * s1) * (s2 * (s3 * s6)) + d1 * (s2 * (s3 * s6)) + d2) mod s4 + s5), meshShape = 1x1, chipIds = [0]> loc(#loc)
      func.func public @main(%arg0: tensor<512x128xbf16, #ttnn_layout> {ttcore.argument_type = #ttcore.argument_type<input>, ttcore.local_shape = #ttcore<local_shape local_shape = tensor<512x128xbf16>>, ttcore.shard_status = #ttcore.shard_status<presharded>} loc("x"), %arg1: tensor<128x512xbf16, #ttnn_layout1> {ttcore.argument_type = #ttcore.argument_type<input>, ttcore.local_shape = #ttcore<local_shape local_shape = tensor<128x512xbf16>>, ttcore.shard_status = #ttcore.shard_status<presharded>} loc("y")) -> (tensor<512x512xf32, #ttnn_layout2> {jax.result_info = "result", ttcore.local_shape = #ttcore<local_shape local_shape = tensor<512x512xf32>>, ttcore.shard_status = #ttcore.shard_status<presharded>}) attributes {tt.function_type = "forward_device"} {
        %0 = "ttnn.to_layout"(%arg0) : (tensor<512x128xbf16, #ttnn_layout>) -> tensor<512x128xbf16, #ttnn_layout3> loc(#loc1)
        "ttnn.deallocate"(%arg0) <{force = false}> : (tensor<512x128xbf16, #ttnn_layout>) -> () loc(#loc1)
        %1 = "ttnn.to_layout"(%arg1) : (tensor<128x512xbf16, #ttnn_layout1>) -> tensor<128x512xbf16, #ttnn_layout4> loc(#loc2)
        "ttnn.deallocate"(%arg1) <{force = false}> : (tensor<128x512xbf16, #ttnn_layout1>) -> () loc(#loc2)
        %2 = "ttnn.matmul"(%0, %1) <{compute_config = #ttnn.device_compute_kernel_config<math_fidelity = hifi4, fp32_dest_acc_en = true>, transpose_a = false, transpose_b = false}> : (tensor<512x128xbf16, #ttnn_layout3>, tensor<128x512xbf16, #ttnn_layout4>) -> tensor<512x512xf32, #ttnn_layout2> loc(#loc11)
        "ttnn.deallocate"(%1) <{force = false}> : (tensor<128x512xbf16, #ttnn_layout4>) -> () loc(#loc11)
        "ttnn.deallocate"(%0) <{force = false}> : (tensor<512x128xbf16, #ttnn_layout3>) -> () loc(#loc11)
        return %2 : tensor<512x512xf32, #ttnn_layout2> loc(#loc)
      } loc(#loc)
    } loc(#loc)
  } loc(#loc)
} loc(#loc)
#loc = loc(unknown)
#loc3 = loc("/home/user/GitHub/GenRecon/experiments/tenstorrent/jax_matmul_dtype_probe.py":82:23 to 83:92)
#loc4 = loc("/home/user/GitHub/GenRecon/experiments/tenstorrent/jax_matmul_dtype_probe.py":86:22 to :47)
#loc5 = loc("/home/user/GitHub/GenRecon/experiments/tenstorrent/jax_matmul_dtype_probe.py":130:4 to :10)
#loc6 = loc("main.<locals>.dot"(#loc3))
#loc7 = loc("main"(#loc4))
#loc8 = loc("<module>"(#loc5))
#loc9 = loc(callsite(#loc7 at #loc8))
#loc10 = loc(callsite(#loc6 at #loc9))
#loc11 = loc("jit(dot)/dot_general"(#loc10))
