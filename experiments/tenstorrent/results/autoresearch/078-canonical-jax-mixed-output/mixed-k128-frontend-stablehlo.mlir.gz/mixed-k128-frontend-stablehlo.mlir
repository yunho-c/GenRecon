module @jit_dot attributes {mhlo.num_partitions = 1 : i32, mhlo.num_replicas = 1 : i32} {
  sdy.mesh @empty_mesh = <[]>
  func.func public @main(%arg0: tensor<512x128xbf16> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}, %arg1: tensor<128x512xbf16> {sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}) -> (tensor<512x512xf32> {jax.result_info = "result", sdy.sharding = #sdy.sharding<@empty_mesh, [{}, {}]>}) {
    %0 = stablehlo.dot_general %arg0, %arg1, contracting_dims = [1] x [0], precision = [HIGHEST, HIGHEST] : (tensor<512x128xbf16>, tensor<128x512xbf16>) -> tensor<512x512xf32>
    return %0 : tensor<512x512xf32>
  }
}
