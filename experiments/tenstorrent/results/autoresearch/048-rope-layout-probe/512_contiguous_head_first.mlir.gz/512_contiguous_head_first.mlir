#dram = #ttnn.buffer_type<dram>
#loc = loc(unknown)
#loc1 = loc("p0.2")
#loc2 = loc("p1.4")
#loc3 = loc("p2.8")
#loc4 = loc("p3.17")
#system_desc = #ttcore.system_desc<[{role = host, target_triple = "x86_64-pc-linux"}], [{arch = <wormhole_b0>, grid = 8x8, coord_translation_offsets = 18x18, l1_size = 1499136, num_dram_channels = 12, dram_channel_size = 1073741824, noc_l1_address_align_bytes = 16, pcie_address_align_bytes = 32, noc_dram_address_align_bytes = 32, l1_unreserved_base = 105536, erisc_l1_unreserved_base = 98304, dram_unreserved_base = 1048640, dram_unreserved_end = 1073108608, supported_data_types = [<f32>, <f16>, <bf16>, <bfp_f8>, <bfp_bf8>, <bfp_f4>, <bfp_bf4>, <bfp_f2>, <bfp_bf2>, <u32>, <u16>, <u8>, <si32>], supported_tile_sizes = [ 4x16,  16x16,  32x16,  4x32,  16x32,  32x32], dst_physical_size_tiles = 16, num_cbs = 64, num_compute_threads = 1, num_datamovement_threads = 2, dram_grid = 1x12, dram_bank_to_logical_worker_noc0 = [(7, 3), (0, 0), (4, 0), (5, 0), (0, 4), (3, 7), (1, 4), (7, 4), (6, 4), (2, 4), (4, 4), (5, 4)], dram_bank_to_logical_worker_noc1 = [(7, 3), (0, 0), (4, 0), (5, 0), (0, 4), (3, 7), (1, 4), (7, 4), (6, 4), (2, 4), (4, 4), (5, 4)]}], [0], [1 : i32], [ 0x0x0x0]>
#system_memory = #ttnn.buffer_type<system_memory>
#ttnn_layout = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 512 + d1 * 512 + d2, d3), <1x1>, memref<512x128xf32, #system_memory>>
#ttnn_layout1 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 16384 + d1 * 32 + d2, d3), <1x1>, memref<512x4x!ttcore.tile<32x32, f32>, #dram>, <interleaved>>
#ttnn_layout2 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 512 + d1 + d2, d3), <1x1>, memref<512x128xf32, #system_memory>>
#ttnn_layout3 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 16384 + d1 * 32 + d2, d3), <1x1>, memref<512x4x!ttcore.tile<32x32, f32>, #system_memory>>
#ttnn_layout4 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<4x192x!ttcore.tile<32x32, f32>, #dram>, <interleaved>>
#ttnn_layout5 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<128x6144xf32, #system_memory>>
#ttnn_layout6 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<4x192x!ttcore.tile<32x32, f32>, #system_memory>>
#ttnn_layout7 = #ttnn.ttnn_layout<(d0) -> (0, d0), <1x1>, memref<1x128xsi32, #system_memory>>
#ttnn_layout8 = #ttnn.ttnn_layout<(d0) -> (0, d0), <1x1>, memref<1x128xui32, #dram>, <interleaved>>
#ttnn_layout9 = #ttnn.ttnn_layout<(d0) -> (0, d0), <1x1>, memref<1x128xui32, #system_memory>>
#ttnn_layout10 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 6144 + d1 * 12 + d2, d3), <1x1>, memref<6144x128xbf16, #dram>, <interleaved>>
#ttnn_layout11 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 6144 + d1 * 512 + d2, d3), <1x1>, memref<192x4x!ttcore.tile<32x32, bf16>, #dram>, <interleaved>>
#ttnn_layout12 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 16384 + d1 * 32 + d2, d3), <1x1>, memref<512x4x!ttcore.tile<32x32, bf16>, #dram>, <interleaved>>
#ttnn_layout13 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 6144 + d1 * 512 + d2, d3), <1x1>, memref<192x4x!ttcore.tile<32x32, f32>, #dram>, <interleaved>>
#ttnn_layout14 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 32 + d1 * 32 + d2, d3), <1x1>, memref<128x16x!ttcore.tile<32x32, bf16>, #dram>, <interleaved>>
#ttnn_layout15 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<4x192x!ttcore.tile<32x32, bf16>, #dram>, <interleaved>>
#ttnn_layout16 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<128x6144xbf16, #dram>, <interleaved>>
#ttnn_layout17 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 32 + d1 * 32 + d2, d3), <1x1>, memref<128x16x!ttcore.tile<32x32, f32>, #dram>, <interleaved>>
module @SyncTensorsGraph.28 attributes {mhlo.cross_program_prefetches = [], mhlo.input_output_alias = [], mhlo.is_dynamic = false, mhlo.use_auto_spmd_partitioning = false, ttcore.meshes = #ttcore.meshes<[<"mesh" = 1x1>]>} {
  ttcore.device_module {
    builtin.module @SyncTensorsGraph.28 attributes {mhlo.cross_program_prefetches = [], mhlo.input_output_alias = [], mhlo.is_dynamic = false, mhlo.use_auto_spmd_partitioning = false, ttcore.meshes = #ttcore.meshes<[<"mesh" = 1x1>]>, ttcore.system_desc = #system_desc, ttnn.l1_const_eval_usage = 1024 : ui64} {
      ttcore.device @default_device = <workerGrid = #ttcore.grid<8x8, virt_to_physical_map = (d0, d1) -> (0, d0, d1), physical_to_virt_map = (d0, d1, d2) -> (d1, d2)>, dramGrid = #ttcore.grid<1x12>, l1Map = (d0, d1, d2)[s0] -> (0, d0, d1, d2 + s0), dramMap = (d0, d1, d2)[s0, s1, s2, s3, s4, s5, s6] -> (0, 0, (((d0 * s1) * (s2 * (s3 * s6)) + d1 * (s2 * (s3 * s6)) + d2) floordiv s4) mod 12, ((((d0 * s1) * (s2 * (s3 * s6)) + d1 * (s2 * (s3 * s6)) + d2) floordiv s4) floordiv 12) * s4 + ((d0 * s1) * (s2 * (s3 * s6)) + d1 * (s2 * (s3 * s6)) + d2) mod s4 + s5), meshShape = 1x1, chipIds = [0]> loc(#loc)
      func.func private @main_const_eval_0(%arg0: tensor<1x1x512x128xf32, #ttnn_layout> loc(unknown)) -> tensor<1x512x1x128xf32, #ttnn_layout1> attributes {tt.function_type = "const_eval"} {
        %0 = "ttnn.get_device"() <{mesh_offset = #ttnn<mesh_offset 0x0>, mesh_shape = #ttnn<mesh_shape 1x1>}> : () -> !ttnn.device loc(#loc)
        %1 = call @cpu_hoisted_const_eval_b02b55a2(%arg0) {ttir.cpu_hoist_call} : (tensor<1x1x512x128xf32, #ttnn_layout>) -> tensor<1x512x1x128xf32, #ttnn_layout2> loc(#loc)
        %2 = "ttnn.to_layout"(%1) : (tensor<1x512x1x128xf32, #ttnn_layout2>) -> tensor<1x512x1x128xf32, #ttnn_layout3> loc(#loc)
        "ttnn.deallocate"(%1) <{force = false}> : (tensor<1x512x1x128xf32, #ttnn_layout2>) -> () loc(#loc)
        %3 = "ttnn.to_device"(%2, %0) : (tensor<1x512x1x128xf32, #ttnn_layout3>, !ttnn.device) -> tensor<1x512x1x128xf32, #ttnn_layout1> loc(#loc)
        "ttnn.deallocate"(%2) <{force = false}> : (tensor<1x512x1x128xf32, #ttnn_layout3>) -> () loc(#loc)
        return %3 : tensor<1x512x1x128xf32, #ttnn_layout1> loc(#loc)
      } loc(#loc)
      func.func private @main_const_eval_1(%arg0: tensor<1x1x512x128xf32, #ttnn_layout> loc(unknown)) -> tensor<128x6144xf32, #ttnn_layout4> attributes {tt.function_type = "const_eval"} {
        %0 = "ttnn.get_device"() <{mesh_offset = #ttnn<mesh_offset 0x0>, mesh_shape = #ttnn<mesh_shape 1x1>}> : () -> !ttnn.device loc(#loc)
        %1 = call @cpu_hoisted_const_eval_1b8513c3(%arg0) {ttir.cpu_hoist_call} : (tensor<1x1x512x128xf32, #ttnn_layout>) -> tensor<128x6144xf32, #ttnn_layout5> loc(#loc)
        %2 = "ttnn.to_layout"(%1) : (tensor<128x6144xf32, #ttnn_layout5>) -> tensor<128x6144xf32, #ttnn_layout6> loc(#loc)
        "ttnn.deallocate"(%1) <{force = false}> : (tensor<128x6144xf32, #ttnn_layout5>) -> () loc(#loc)
        %3 = "ttnn.to_device"(%2, %0) : (tensor<128x6144xf32, #ttnn_layout6>, !ttnn.device) -> tensor<128x6144xf32, #ttnn_layout4> loc(#loc)
        "ttnn.deallocate"(%2) <{force = false}> : (tensor<128x6144xf32, #ttnn_layout6>) -> () loc(#loc)
        return %3 : tensor<128x6144xf32, #ttnn_layout4> loc(#loc)
      } loc(#loc)
      func.func private @main_const_eval_2(%arg0: tensor<128xsi32, #ttnn_layout7> loc(unknown)) -> tensor<128xui32, #ttnn_layout8> attributes {tt.function_type = "const_eval"} {
        %0 = "ttnn.get_device"() <{mesh_offset = #ttnn<mesh_offset 0x0>, mesh_shape = #ttnn<mesh_shape 1x1>}> : () -> !ttnn.device loc(#loc)
        %1 = call @cpu_hoisted_const_eval_b6969c39(%arg0) {ttir.cpu_hoist_call} : (tensor<128xsi32, #ttnn_layout7>) -> tensor<128xui32, #ttnn_layout9> loc(#loc)
        %2 = "ttnn.to_device"(%1, %0) : (tensor<128xui32, #ttnn_layout9>, !ttnn.device) -> tensor<128xui32, #ttnn_layout8> loc(#loc)
        "ttnn.deallocate"(%1) <{force = false}> : (tensor<128xui32, #ttnn_layout9>) -> () loc(#loc)
        return %2 : tensor<128xui32, #ttnn_layout8> loc(#loc)
      } loc(#loc)
      func.func @main(%arg0: tensor<1x1x512x128xf32, #ttnn_layout> {ttcore.argument_type = #ttcore.argument_type<constant>, ttcore.local_shape = #ttcore<local_shape local_shape = tensor<1x1x512x128xf32>>, ttcore.shard_status = #ttcore.shard_status<unsharded>, ttir.name = "rope.signed_sine"} loc("p0.2"), %arg1: tensor<128xsi32, #ttnn_layout7> {ttcore.argument_type = #ttcore.argument_type<constant>, ttcore.local_shape = #ttcore<local_shape local_shape = tensor<128xi64>>, ttcore.shard_status = #ttcore.shard_status<unsharded>, ttir.name = "rope.partner_ids"} loc("p1.4"), %arg2: tensor<1x512x12x128xbf16, #ttnn_layout10> {ttcore.argument_type = #ttcore.argument_type<input>, ttcore.local_shape = #ttcore<local_shape local_shape = tensor<1x512x12x128xbf16>>, ttcore.shard_status = #ttcore.shard_status<unsharded>, ttir.name = "arg3_1"} loc("p2.8"), %arg3: tensor<1x1x512x128xf32, #ttnn_layout> {ttcore.argument_type = #ttcore.argument_type<constant>, ttcore.local_shape = #ttcore<local_shape local_shape = tensor<1x1x512x128xf32>>, ttcore.shard_status = #ttcore.shard_status<unsharded>, ttir.name = "rope.cosine"} loc("p3.17")) -> (tensor<1x12x512x128xbf16, #ttnn_layout11> {ttcore.local_shape = #ttcore<local_shape local_shape = tensor<1x12x512x128xbf16>>, ttcore.shard_status = #ttcore.shard_status<presharded>}) attributes {tt.function_type = "forward_device"} {
        %0 = ttcore.load_cached(@main_const_eval_0, [%arg3]) : (tensor<1x1x512x128xf32, #ttnn_layout>) -> tensor<1x512x1x128xf32, #ttnn_layout1> loc(#loc)
        "ttnn.deallocate"(%arg3) <{force = false}> : (tensor<1x1x512x128xf32, #ttnn_layout>) -> () loc(#loc)
        %1 = ttcore.load_cached(@main_const_eval_1, [%arg0]) : (tensor<1x1x512x128xf32, #ttnn_layout>) -> tensor<128x6144xf32, #ttnn_layout4> loc(#loc)
        "ttnn.deallocate"(%arg0) <{force = false}> : (tensor<1x1x512x128xf32, #ttnn_layout>) -> () loc(#loc)
        %2 = ttcore.load_cached(@main_const_eval_2, [%arg1]) : (tensor<128xsi32, #ttnn_layout7>) -> tensor<128xui32, #ttnn_layout8> loc(#loc)
        "ttnn.deallocate"(%arg1) <{force = false}> : (tensor<128xsi32, #ttnn_layout7>) -> () loc(#loc)
        %3 = "ttnn.to_layout"(%arg2) : (tensor<1x512x12x128xbf16, #ttnn_layout10>) -> tensor<1x512x12x128xbf16, #ttnn_layout12> loc(#loc3)
        "ttnn.deallocate"(%arg2) <{force = false}> : (tensor<1x512x12x128xbf16, #ttnn_layout10>) -> () loc(#loc3)
        %4 = "ttnn.typecast"(%3) : (tensor<1x512x12x128xbf16, #ttnn_layout12>) -> tensor<1x512x12x128xf32, #ttnn_layout1> loc(#loc5)
        %5 = "ttnn.multiply"(%4, %0) : (tensor<1x512x12x128xf32, #ttnn_layout1>, tensor<1x512x1x128xf32, #ttnn_layout1>) -> tensor<1x512x12x128xf32, #ttnn_layout1> loc(#loc6)
        "ttnn.deallocate"(%4) <{force = false}> : (tensor<1x512x12x128xf32, #ttnn_layout1>) -> () loc(#loc6)
        "ttnn.deallocate"(%0) <{force = false}> : (tensor<1x512x1x128xf32, #ttnn_layout1>) -> () loc(#loc6)
        %6 = "ttnn.permute"(%5) <{permutation = array<i64: 0, 2, 1, 3>}> : (tensor<1x512x12x128xf32, #ttnn_layout1>) -> tensor<1x12x512x128xf32, #ttnn_layout13> loc(#loc6)
        "ttnn.deallocate"(%5) <{force = false}> : (tensor<1x512x12x128xf32, #ttnn_layout1>) -> () loc(#loc6)
        %7 = "ttnn.permute"(%3) <{permutation = array<i64: 3, 0, 2, 1>}> : (tensor<1x512x12x128xbf16, #ttnn_layout12>) -> tensor<128x1x12x512xbf16, #ttnn_layout14> loc(#loc13)
        "ttnn.deallocate"(%3) <{force = false}> : (tensor<1x512x12x128xbf16, #ttnn_layout12>) -> () loc(#loc13)
        %8 = "ttnn.reshape"(%7) <{shape = [128 : i32, 6144 : i32]}> : (tensor<128x1x12x512xbf16, #ttnn_layout14>) -> tensor<128x6144xbf16, #ttnn_layout15> loc(#loc14)
        "ttnn.deallocate"(%7) <{force = false}> : (tensor<128x1x12x512xbf16, #ttnn_layout14>) -> () loc(#loc14)
        %9 = "ttnn.to_layout"(%8) : (tensor<128x6144xbf16, #ttnn_layout15>) -> tensor<128x6144xbf16, #ttnn_layout16> loc(#loc14)
        "ttnn.deallocate"(%8) <{force = false}> : (tensor<128x6144xbf16, #ttnn_layout15>) -> () loc(#loc14)
        %10 = "ttnn.embedding"(%2, %9) : (tensor<128xui32, #ttnn_layout8>, tensor<128x6144xbf16, #ttnn_layout16>) -> tensor<128x6144xbf16, #ttnn_layout15> loc(#loc7)
        "ttnn.deallocate"(%9) <{force = false}> : (tensor<128x6144xbf16, #ttnn_layout16>) -> () loc(#loc7)
        "ttnn.deallocate"(%2) <{force = false}> : (tensor<128xui32, #ttnn_layout8>) -> () loc(#loc7)
        %11 = "ttnn.typecast"(%10) : (tensor<128x6144xbf16, #ttnn_layout15>) -> tensor<128x6144xf32, #ttnn_layout4> loc(#loc8)
        "ttnn.deallocate"(%10) <{force = false}> : (tensor<128x6144xbf16, #ttnn_layout15>) -> () loc(#loc8)
        %12 = "ttnn.multiply"(%11, %1) : (tensor<128x6144xf32, #ttnn_layout4>, tensor<128x6144xf32, #ttnn_layout4>) -> tensor<128x6144xf32, #ttnn_layout4> loc(#loc9)
        "ttnn.deallocate"(%11) <{force = false}> : (tensor<128x6144xf32, #ttnn_layout4>) -> () loc(#loc9)
        "ttnn.deallocate"(%1) <{force = false}> : (tensor<128x6144xf32, #ttnn_layout4>) -> () loc(#loc9)
        %13 = "ttnn.reshape"(%12) <{shape = [128 : i32, 1 : i32, 12 : i32, 512 : i32]}> : (tensor<128x6144xf32, #ttnn_layout4>) -> tensor<128x1x12x512xf32, #ttnn_layout17> loc(#loc9)
        "ttnn.deallocate"(%12) <{force = false}> : (tensor<128x6144xf32, #ttnn_layout4>) -> () loc(#loc9)
        %14 = "ttnn.permute"(%13) <{permutation = array<i64: 1, 2, 3, 0>}> : (tensor<128x1x12x512xf32, #ttnn_layout17>) -> tensor<1x12x512x128xf32, #ttnn_layout13> loc(#loc9)
        "ttnn.deallocate"(%13) <{force = false}> : (tensor<128x1x12x512xf32, #ttnn_layout17>) -> () loc(#loc9)
        %15 = "ttnn.add"(%6, %14) : (tensor<1x12x512x128xf32, #ttnn_layout13>, tensor<1x12x512x128xf32, #ttnn_layout13>) -> tensor<1x12x512x128xf32, #ttnn_layout13> loc(#loc10)
        "ttnn.deallocate"(%14) <{force = false}> : (tensor<1x12x512x128xf32, #ttnn_layout13>) -> () loc(#loc10)
        "ttnn.deallocate"(%6) <{force = false}> : (tensor<1x12x512x128xf32, #ttnn_layout13>) -> () loc(#loc10)
        %16 = "ttnn.typecast"(%15) : (tensor<1x12x512x128xf32, #ttnn_layout13>) -> tensor<1x12x512x128xbf16, #ttnn_layout11> loc(#loc11)
        "ttnn.deallocate"(%15) <{force = false}> : (tensor<1x12x512x128xf32, #ttnn_layout13>) -> () loc(#loc11)
        return %16 : tensor<1x12x512x128xbf16, #ttnn_layout11> loc(#loc)
      } loc(#loc)
      func.func private @cpu_hoisted_const_eval_b02b55a2(tensor<1x1x512x128xf32, #ttnn_layout>) -> tensor<1x512x1x128xf32, #ttnn_layout2> attributes {func_hash = "b02b55a2c23dee3376cc66e57614bef098b1b7f1db7a311a39edfbff4b007b59", tt.function_type = "forward_cpu_declaration"} loc(#loc)
      func.func private @cpu_hoisted_const_eval_1b8513c3(tensor<1x1x512x128xf32, #ttnn_layout>) -> tensor<128x6144xf32, #ttnn_layout5> attributes {func_hash = "1b8513c3708de2aa81933f1a63988c114326bfe8497e1361480fb5087a8eade2", tt.function_type = "forward_cpu_declaration"} loc(#loc)
      func.func private @cpu_hoisted_const_eval_b6969c39(tensor<128xsi32, #ttnn_layout7>) -> tensor<128xui32, #ttnn_layout9> attributes {func_hash = "b6969c39e22d5da7e2d69754efaf744feac2607a4022bb881695d6cf6de34818", tt.function_type = "forward_cpu_declaration"} loc(#loc)
    } loc(#loc)
  } loc(#loc)
  ttcore.cpu_module {
    builtin.module {
      func.func @cpu_hoisted_const_eval_b02b55a2(%arg0: tensor<1x1x512x128xf32> {bufferization.access = "read"} loc(unknown)) -> tensor<1x512x1x128xf32> attributes {arg_ranks = [4], func_hash = "b02b55a2c23dee3376cc66e57614bef098b1b7f1db7a311a39edfbff4b007b59", result_ranks = [4], tt.function_type = "forward_cpu"} {
        %0 = "ttir.permute"(%arg0) <{permutation = array<i64: 0, 2, 1, 3>}> : (tensor<1x1x512x128xf32>) -> tensor<1x512x1x128xf32> loc(#loc5)
        return %0 : tensor<1x512x1x128xf32> loc(#loc)
      } loc(#loc)
      func.func @cpu_hoisted_const_eval_1b8513c3(%arg0: tensor<1x1x512x128xf32> {bufferization.access = "read"} loc(unknown)) -> tensor<128x6144xf32> attributes {arg_ranks = [4], func_hash = "1b8513c3708de2aa81933f1a63988c114326bfe8497e1361480fb5087a8eade2", result_ranks = [2], tt.function_type = "forward_cpu"} {
        %0 = "ttir.permute"(%arg0) <{permutation = array<i64: 3, 0, 1, 2>}> : (tensor<1x1x512x128xf32>) -> tensor<128x1x1x512xf32> loc(#loc8)
        %1 = "ttir.broadcast"(%0) <{broadcast_dimensions = array<i64: 1, 1, 12, 1>}> : (tensor<128x1x1x512xf32>) -> tensor<128x1x12x512xf32> loc(#loc15)
        %2 = "ttir.reshape"(%1) <{shape = [128 : i32, 6144 : i32]}> : (tensor<128x1x12x512xf32>) -> tensor<128x6144xf32> loc(#loc8)
        return %2 : tensor<128x6144xf32> loc(#loc)
      } loc(#loc)
      func.func @cpu_hoisted_const_eval_b6969c39(%arg0: tensor<128xi32> {bufferization.access = "read"} loc(unknown)) -> tensor<128xi32> attributes {arg_ranks = [1], func_hash = "b6969c39e22d5da7e2d69754efaf744feac2607a4022bb881695d6cf6de34818", result_ranks = [1], tt.function_type = "forward_cpu"} {
        %0 = "ttir.typecast"(%arg0) <{conservative_folding = false}> : (tensor<128xi32>) -> tensor<128xi32> loc(#loc12)
        return %0 : tensor<128xi32> loc(#loc)
      } loc(#loc)
    } loc(#loc)
  } loc(#loc)
} loc(#loc)
#loc5 = loc("convert.19")
#loc6 = loc("multiply.22")
#loc7 = loc("gather.12")
#loc8 = loc("convert.13")
#loc9 = loc("multiply.16")
#loc10 = loc("add.25")
#loc11 = loc("convert.26")
#loc12 = loc("convert.11")
#loc13 = loc("gather.12_permuteInput"(#loc7))
#loc14 = loc("gather.12_reshapeInput"(#loc7))
#loc15 = loc("multiply.16_broadcast"(#loc9))
