#dram = #ttnn.buffer_type<dram>
#loc = loc(unknown)
#loc1 = loc("p0.2")
#loc2 = loc("p1.8")
#loc3 = loc("p2.12")
#loc4 = loc("p3.19")
#system_desc = #ttcore.system_desc<[{role = host, target_triple = "x86_64-pc-linux"}], [{arch = <wormhole_b0>, grid = 8x8, coord_translation_offsets = 18x18, l1_size = 1499136, num_dram_channels = 12, dram_channel_size = 1073741824, noc_l1_address_align_bytes = 16, pcie_address_align_bytes = 32, noc_dram_address_align_bytes = 32, l1_unreserved_base = 105536, erisc_l1_unreserved_base = 98304, dram_unreserved_base = 1048640, dram_unreserved_end = 1073108608, supported_data_types = [<f32>, <f16>, <bf16>, <bfp_f8>, <bfp_bf8>, <bfp_f4>, <bfp_bf4>, <bfp_f2>, <bfp_bf2>, <u32>, <u16>, <u8>, <si32>], supported_tile_sizes = [ 4x16,  16x16,  32x16,  4x32,  16x32,  32x32], dst_physical_size_tiles = 16, num_cbs = 64, num_compute_threads = 1, num_datamovement_threads = 2, dram_grid = 1x12, dram_bank_to_logical_worker_noc0 = [(7, 3), (0, 0), (4, 0), (5, 0), (0, 4), (3, 7), (1, 4), (7, 4), (6, 4), (2, 4), (4, 4), (5, 4)], dram_bank_to_logical_worker_noc1 = [(7, 3), (0, 0), (4, 0), (5, 0), (0, 4), (3, 7), (1, 4), (7, 4), (6, 4), (2, 4), (4, 4), (5, 4)]}], [0], [1 : i32], [ 0x0x0x0]>
#system_memory = #ttnn.buffer_type<system_memory>
#ttnn_layout = #ttnn.ttnn_layout<(d0) -> (0, d0), <1x1>, memref<1x128xsi32, #system_memory>>
#ttnn_layout1 = #ttnn.ttnn_layout<(d0) -> (0, d0), <1x1>, memref<1x128xui32, #dram>, <interleaved>>
#ttnn_layout2 = #ttnn.ttnn_layout<(d0) -> (0, d0), <1x1>, memref<1x128xui32, #system_memory>>
#ttnn_layout3 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 4096 + d1 * 4096 + d2, d3), <1x1>, memref<4096x128xf32, #system_memory>>
#ttnn_layout4 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<4x1536x!ttcore.tile<32x32, f32>, #dram>, <interleaved>>
#ttnn_layout5 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<128x49152xf32, #system_memory>>
#ttnn_layout6 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<4x1536x!ttcore.tile<32x32, f32>, #system_memory>>
#ttnn_layout7 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 49152 + d1 * 12 + d2, d3), <1x1>, memref<49152x128xf32, #dram>, <interleaved>>
#ttnn_layout8 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 4096 + d1 * 4096 + d2, d3), <1x1>, memref<128x4x!ttcore.tile<32x32, f32>, #dram>, <interleaved>>
#ttnn_layout9 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 49152 + d1 * 4096 + d2, d3), <1x1>, memref<1536x4x!ttcore.tile<32x32, f32>, #dram>, <interleaved>>
#ttnn_layout10 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 131072 + d1 * 32 + d2, d3), <1x1>, memref<4096x4x!ttcore.tile<32x32, f32>, #dram>, <interleaved>>
#ttnn_layout11 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<1536x4x!ttcore.tile<32x32, f32>, #dram>, <interleaved>>
#ttnn_layout12 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<4x1536x!ttcore.tile<32x32, bf16>, #dram>, <interleaved>>
#ttnn_layout13 = #ttnn.ttnn_layout<(d0, d1) -> (d0, d1), <1x1>, memref<128x49152xbf16, #dram>, <interleaved>>
module @SyncTensorsGraph.31 attributes {mhlo.cross_program_prefetches = [], mhlo.input_output_alias = [], mhlo.is_dynamic = false, mhlo.use_auto_spmd_partitioning = false, ttcore.meshes = #ttcore.meshes<[<"mesh" = 1x1>]>} {
  ttcore.device_module {
    builtin.module @SyncTensorsGraph.31 attributes {mhlo.cross_program_prefetches = [], mhlo.input_output_alias = [], mhlo.is_dynamic = false, mhlo.use_auto_spmd_partitioning = false, ttcore.meshes = #ttcore.meshes<[<"mesh" = 1x1>]>, ttcore.system_desc = #system_desc, ttnn.l1_const_eval_usage = 1024 : ui64} {
      ttcore.device @default_device = <workerGrid = #ttcore.grid<8x8, virt_to_physical_map = (d0, d1) -> (0, d0, d1), physical_to_virt_map = (d0, d1, d2) -> (d1, d2)>, dramGrid = #ttcore.grid<1x12>, l1Map = (d0, d1, d2)[s0] -> (0, d0, d1, d2 + s0), dramMap = (d0, d1, d2)[s0, s1, s2, s3, s4, s5, s6] -> (0, 0, (((d0 * s1) * (s2 * (s3 * s6)) + d1 * (s2 * (s3 * s6)) + d2) floordiv s4) mod 12, ((((d0 * s1) * (s2 * (s3 * s6)) + d1 * (s2 * (s3 * s6)) + d2) floordiv s4) floordiv 12) * s4 + ((d0 * s1) * (s2 * (s3 * s6)) + d1 * (s2 * (s3 * s6)) + d2) mod s4 + s5), meshShape = 1x1, chipIds = [0]> loc(#loc)
      func.func private @main_const_eval_0(%arg0: tensor<128xsi32, #ttnn_layout> loc(unknown)) -> tensor<128xui32, #ttnn_layout1> attributes {tt.function_type = "const_eval"} {
        %0 = "ttnn.get_device"() <{mesh_offset = #ttnn<mesh_offset 0x0>, mesh_shape = #ttnn<mesh_shape 1x1>}> : () -> !ttnn.device loc(#loc)
        %1 = call @cpu_hoisted_const_eval_b6969c39(%arg0) {ttir.cpu_hoist_call} : (tensor<128xsi32, #ttnn_layout>) -> tensor<128xui32, #ttnn_layout2> loc(#loc)
        %2 = "ttnn.to_device"(%1, %0) : (tensor<128xui32, #ttnn_layout2>, !ttnn.device) -> tensor<128xui32, #ttnn_layout1> loc(#loc)
        "ttnn.deallocate"(%1) <{force = false}> : (tensor<128xui32, #ttnn_layout2>) -> () loc(#loc)
        return %2 : tensor<128xui32, #ttnn_layout1> loc(#loc)
      } loc(#loc)
      func.func private @main_const_eval_1(%arg0: tensor<1x1x4096x128xf32, #ttnn_layout3> loc(unknown)) -> tensor<128x49152xf32, #ttnn_layout4> attributes {tt.function_type = "const_eval"} {
        %0 = "ttnn.get_device"() <{mesh_offset = #ttnn<mesh_offset 0x0>, mesh_shape = #ttnn<mesh_shape 1x1>}> : () -> !ttnn.device loc(#loc)
        %1 = call @cpu_hoisted_const_eval_c731b6a9(%arg0) {ttir.cpu_hoist_call} : (tensor<1x1x4096x128xf32, #ttnn_layout3>) -> tensor<128x49152xf32, #ttnn_layout5> loc(#loc)
        %2 = "ttnn.to_layout"(%1) : (tensor<128x49152xf32, #ttnn_layout5>) -> tensor<128x49152xf32, #ttnn_layout6> loc(#loc)
        "ttnn.deallocate"(%1) <{force = false}> : (tensor<128x49152xf32, #ttnn_layout5>) -> () loc(#loc)
        %3 = "ttnn.to_device"(%2, %0) : (tensor<128x49152xf32, #ttnn_layout6>, !ttnn.device) -> tensor<128x49152xf32, #ttnn_layout4> loc(#loc)
        "ttnn.deallocate"(%2) <{force = false}> : (tensor<128x49152xf32, #ttnn_layout6>) -> () loc(#loc)
        return %3 : tensor<128x49152xf32, #ttnn_layout4> loc(#loc)
      } loc(#loc)
      func.func @main(%arg0: tensor<1x1x4096x128xf32, #ttnn_layout3> {ttcore.argument_type = #ttcore.argument_type<constant>, ttcore.local_shape = #ttcore<local_shape local_shape = tensor<1x1x4096x128xf32>>, ttcore.shard_status = #ttcore.shard_status<unsharded>, ttir.name = "rope.signed_sine"} loc("p0.2"), %arg1: tensor<128xsi32, #ttnn_layout> {ttcore.argument_type = #ttcore.argument_type<constant>, ttcore.local_shape = #ttcore<local_shape local_shape = tensor<128xi64>>, ttcore.shard_status = #ttcore.shard_status<unsharded>, ttir.name = "rope.partner_ids"} loc("p1.8"), %arg2: tensor<1x4096x12x128xf32, #ttnn_layout7> {ttcore.argument_type = #ttcore.argument_type<input>, ttcore.local_shape = #ttcore<local_shape local_shape = tensor<1x4096x12x128xf32>>, ttcore.shard_status = #ttcore.shard_status<unsharded>, ttir.name = "arg3_1"} loc("p2.12"), %arg3: tensor<1x1x4096x128xf32, #ttnn_layout8> {ttcore.argument_type = #ttcore.argument_type<constant>, ttcore.local_shape = #ttcore<local_shape local_shape = tensor<1x1x4096x128xf32>>, ttcore.shard_status = #ttcore.shard_status<unsharded>, ttir.name = "rope.cosine"} loc("p3.19")) -> (tensor<1x12x4096x128xf32, #ttnn_layout9> {ttcore.local_shape = #ttcore<local_shape local_shape = tensor<1x12x4096x128xf32>>, ttcore.shard_status = #ttcore.shard_status<presharded>}) attributes {tt.function_type = "forward_device"} {
        %0 = ttcore.load_cached(@main_const_eval_0, [%arg1]) : (tensor<128xsi32, #ttnn_layout>) -> tensor<128xui32, #ttnn_layout1> loc(#loc)
        "ttnn.deallocate"(%arg1) <{force = false}> : (tensor<128xsi32, #ttnn_layout>) -> () loc(#loc)
        %1 = ttcore.load_cached(@main_const_eval_1, [%arg0]) : (tensor<1x1x4096x128xf32, #ttnn_layout3>) -> tensor<128x49152xf32, #ttnn_layout4> loc(#loc)
        "ttnn.deallocate"(%arg0) <{force = false}> : (tensor<1x1x4096x128xf32, #ttnn_layout3>) -> () loc(#loc)
        %2 = "ttnn.to_layout"(%arg2) : (tensor<1x4096x12x128xf32, #ttnn_layout7>) -> tensor<1x4096x12x128xf32, #ttnn_layout10> loc(#loc3)
        "ttnn.deallocate"(%arg2) <{force = false}> : (tensor<1x4096x12x128xf32, #ttnn_layout7>) -> () loc(#loc3)
        %3 = "ttnn.permute"(%2) <{permutation = array<i64: 0, 2, 1, 3>}> : (tensor<1x4096x12x128xf32, #ttnn_layout10>) -> tensor<1x12x4096x128xf32, #ttnn_layout9> loc(#loc5)
        "ttnn.deallocate"(%2) <{force = false}> : (tensor<1x4096x12x128xf32, #ttnn_layout10>) -> () loc(#loc5)
        %4 = "ttnn.reshape"(%3) <{shape = [49152 : i32, 128 : i32]}> : (tensor<1x12x4096x128xf32, #ttnn_layout9>) -> tensor<49152x128xf32, #ttnn_layout11> loc(#loc6)
        %5 = "ttnn.multiply"(%3, %arg3) : (tensor<1x12x4096x128xf32, #ttnn_layout9>, tensor<1x1x4096x128xf32, #ttnn_layout8>) -> tensor<1x12x4096x128xf32, #ttnn_layout9> loc(#loc7)
        "ttnn.deallocate"(%3) <{force = false}> : (tensor<1x12x4096x128xf32, #ttnn_layout9>) -> () loc(#loc7)
        "ttnn.deallocate"(%arg3) <{force = false}> : (tensor<1x1x4096x128xf32, #ttnn_layout8>) -> () loc(#loc7)
        %6 = "ttnn.permute"(%4) <{permutation = array<i64: 1, 0>}> : (tensor<49152x128xf32, #ttnn_layout11>) -> tensor<128x49152xf32, #ttnn_layout4> loc(#loc13)
        "ttnn.deallocate"(%4) <{force = false}> : (tensor<49152x128xf32, #ttnn_layout11>) -> () loc(#loc13)
        %7 = "ttnn.typecast"(%6) : (tensor<128x49152xf32, #ttnn_layout4>) -> tensor<128x49152xbf16, #ttnn_layout12> loc(#loc13)
        "ttnn.deallocate"(%6) <{force = false}> : (tensor<128x49152xf32, #ttnn_layout4>) -> () loc(#loc13)
        %8 = "ttnn.to_layout"(%7) : (tensor<128x49152xbf16, #ttnn_layout12>) -> tensor<128x49152xbf16, #ttnn_layout13> loc(#loc13)
        "ttnn.deallocate"(%7) <{force = false}> : (tensor<128x49152xbf16, #ttnn_layout12>) -> () loc(#loc13)
        %9 = "ttnn.embedding"(%0, %8) : (tensor<128xui32, #ttnn_layout1>, tensor<128x49152xbf16, #ttnn_layout13>) -> tensor<128x49152xbf16, #ttnn_layout12> loc(#loc8)
        "ttnn.deallocate"(%8) <{force = false}> : (tensor<128x49152xbf16, #ttnn_layout13>) -> () loc(#loc8)
        "ttnn.deallocate"(%0) <{force = false}> : (tensor<128xui32, #ttnn_layout1>) -> () loc(#loc8)
        %10 = "ttnn.typecast"(%9) : (tensor<128x49152xbf16, #ttnn_layout12>) -> tensor<128x49152xf32, #ttnn_layout4> loc(#loc8)
        "ttnn.deallocate"(%9) <{force = false}> : (tensor<128x49152xbf16, #ttnn_layout12>) -> () loc(#loc8)
        %11 = "ttnn.multiply"(%10, %1) : (tensor<128x49152xf32, #ttnn_layout4>, tensor<128x49152xf32, #ttnn_layout4>) -> tensor<128x49152xf32, #ttnn_layout4> loc(#loc9)
        "ttnn.deallocate"(%10) <{force = false}> : (tensor<128x49152xf32, #ttnn_layout4>) -> () loc(#loc9)
        "ttnn.deallocate"(%1) <{force = false}> : (tensor<128x49152xf32, #ttnn_layout4>) -> () loc(#loc9)
        %12 = "ttnn.permute"(%11) <{permutation = array<i64: 1, 0>}> : (tensor<128x49152xf32, #ttnn_layout4>) -> tensor<49152x128xf32, #ttnn_layout11> loc(#loc9)
        "ttnn.deallocate"(%11) <{force = false}> : (tensor<128x49152xf32, #ttnn_layout4>) -> () loc(#loc9)
        %13 = "ttnn.reshape"(%12) <{shape = [1 : i32, 12 : i32, 4096 : i32, 128 : i32]}> : (tensor<49152x128xf32, #ttnn_layout11>) -> tensor<1x12x4096x128xf32, #ttnn_layout9> loc(#loc9)
        "ttnn.deallocate"(%12) <{force = false}> : (tensor<49152x128xf32, #ttnn_layout11>) -> () loc(#loc9)
        %14 = "ttnn.add"(%5, %13) : (tensor<1x12x4096x128xf32, #ttnn_layout9>, tensor<1x12x4096x128xf32, #ttnn_layout9>) -> tensor<1x12x4096x128xf32, #ttnn_layout9> loc(#loc10)
        "ttnn.deallocate"(%13) <{force = false}> : (tensor<1x12x4096x128xf32, #ttnn_layout9>) -> () loc(#loc10)
        "ttnn.deallocate"(%5) <{force = false}> : (tensor<1x12x4096x128xf32, #ttnn_layout9>) -> () loc(#loc10)
        return %14 : tensor<1x12x4096x128xf32, #ttnn_layout9> loc(#loc)
      } loc(#loc)
      func.func private @cpu_hoisted_const_eval_b6969c39(tensor<128xsi32, #ttnn_layout>) -> tensor<128xui32, #ttnn_layout2> attributes {func_hash = "b6969c39e22d5da7e2d69754efaf744feac2607a4022bb881695d6cf6de34818", tt.function_type = "forward_cpu_declaration"} loc(#loc)
      func.func private @cpu_hoisted_const_eval_c731b6a9(tensor<1x1x4096x128xf32, #ttnn_layout3>) -> tensor<128x49152xf32, #ttnn_layout5> attributes {func_hash = "c731b6a9a12f1bb09a1a5cb70496d7f8c6c59cd14a0ebc088a0de1492a9634dc", tt.function_type = "forward_cpu_declaration"} loc(#loc)
    } loc(#loc)
  } loc(#loc)
  ttcore.cpu_module {
    builtin.module {
      func.func @cpu_hoisted_const_eval_b6969c39(%arg0: tensor<128xi32> {bufferization.access = "read"} loc(unknown)) -> tensor<128xi32> attributes {arg_ranks = [1], func_hash = "b6969c39e22d5da7e2d69754efaf744feac2607a4022bb881695d6cf6de34818", result_ranks = [1], tt.function_type = "forward_cpu"} {
        %0 = "ttir.typecast"(%arg0) <{conservative_folding = false}> : (tensor<128xi32>) -> tensor<128xi32> loc(#loc11)
        return %0 : tensor<128xi32> loc(#loc)
      } loc(#loc)
      func.func @cpu_hoisted_const_eval_c731b6a9(%arg0: tensor<1x1x4096x128xf32> {bufferization.access = "read"} loc(unknown)) -> tensor<128x49152xf32> attributes {arg_ranks = [4], func_hash = "c731b6a9a12f1bb09a1a5cb70496d7f8c6c59cd14a0ebc088a0de1492a9634dc", result_ranks = [2], tt.function_type = "forward_cpu"} {
        %0 = "ttir.broadcast"(%arg0) <{broadcast_dimensions = array<i64: 1, 12, 1, 1>}> : (tensor<1x1x4096x128xf32>) -> tensor<1x12x4096x128xf32> loc(#loc12)
        %1 = "ttir.reshape"(%0) <{shape = [49152 : i32, 128 : i32]}> : (tensor<1x12x4096x128xf32>) -> tensor<49152x128xf32> loc(#loc14)
        %2 = "ttir.permute"(%1) <{permutation = array<i64: 1, 0>}> : (tensor<49152x128xf32>) -> tensor<128x49152xf32> loc(#loc14)
        return %2 : tensor<128x49152xf32> loc(#loc)
      } loc(#loc)
    } loc(#loc)
  } loc(#loc)
} loc(#loc)
#loc5 = loc("transpose.14")
#loc6 = loc("reshape.15")
#loc7 = loc("multiply.25")
#loc8 = loc("gather.17")
#loc9 = loc("multiply.18")
#loc10 = loc("add.28")
#loc11 = loc("convert.16")
#loc12 = loc("broadcast.6")
#loc13 = loc("gather.17_permuteInput"(#loc8))
#loc14 = loc("multiply.18_tm0"(#loc9))
