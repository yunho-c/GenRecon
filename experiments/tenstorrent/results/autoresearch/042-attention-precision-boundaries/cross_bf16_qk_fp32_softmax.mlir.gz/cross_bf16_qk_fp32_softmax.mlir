#dram = #ttnn.buffer_type<dram>
#loc1 = loc("p0.1")
#loc2 = loc("p1.7")
#loc3 = loc("p2.12")
#system_desc = #ttcore.system_desc<[{role = host, target_triple = "x86_64-pc-linux"}], [{arch = <wormhole_b0>, grid = 8x8, coord_translation_offsets = 18x18, l1_size = 1499136, num_dram_channels = 12, dram_channel_size = 1073741824, noc_l1_address_align_bytes = 16, pcie_address_align_bytes = 32, noc_dram_address_align_bytes = 32, l1_unreserved_base = 105536, erisc_l1_unreserved_base = 98304, dram_unreserved_base = 1048640, dram_unreserved_end = 1073108608, supported_data_types = [<f32>, <f16>, <bf16>, <bfp_f8>, <bfp_bf8>, <bfp_f4>, <bfp_bf4>, <bfp_f2>, <bfp_bf2>, <u32>, <u16>, <u8>, <si32>], supported_tile_sizes = [ 4x16,  16x16,  32x16,  4x32,  16x32,  32x32], dst_physical_size_tiles = 16, num_cbs = 64, num_compute_threads = 1, num_datamovement_threads = 2, dram_grid = 1x12, dram_bank_to_logical_worker_noc0 = [(7, 3), (0, 0), (4, 0), (5, 0), (0, 4), (3, 7), (1, 4), (7, 4), (6, 4), (2, 4), (4, 4), (5, 4)], dram_bank_to_logical_worker_noc1 = [(7, 3), (0, 0), (4, 0), (5, 0), (0, 4), (3, 7), (1, 4), (7, 4), (6, 4), (2, 4), (4, 4), (5, 4)]}], [0], [1 : i32], [ 0x0x0x0]>
#ttnn_layout = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 32 + d1 * 32 + d2, d3), <1x1>, memref<1x1x!ttcore.tile<32x32, f32>, #dram>, <interleaved>>
#ttnn_layout1 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 12348 + d1 * 12 + d2, d3), <1x1>, memref<12348x128xbf16, #dram>, <interleaved>>
#ttnn_layout2 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 6144 + d1 * 12 + d2, d3), <1x1>, memref<6144x128xbf16, #dram>, <interleaved>>
#ttnn_layout3 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 16384 + d1 * 32 + d2, d3), <1x1>, memref<512x4x!ttcore.tile<32x32, bf16>, #dram>, <interleaved>>
#ttnn_layout4 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 6144 + d1 * 512 + d2, d3), <1x1>, memref<192x4x!ttcore.tile<32x32, bf16>, #dram>, <interleaved>>
#ttnn_layout5 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 32928 + d1 * 32 + d2, d3), <1x1>, memref<1029x4x!ttcore.tile<32x32, bf16>, #dram>, <interleaved>>
#ttnn_layout6 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 1536 + d1 * 128 + d2, d3), <1x1>, memref<48x33x!ttcore.tile<32x32, bf16>, #dram>, <interleaved>>
#ttnn_layout7 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 6144 + d1 * 512 + d2, d3), <1x1>, memref<192x33x!ttcore.tile<32x32, bf16>, #dram>, <interleaved>>
#ttnn_layout8 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 6144 + d1 * 512 + d2, d3), <1x1>, memref<192x33x!ttcore.tile<32x32, f32>, #dram>, <interleaved>>
#ttnn_layout9 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 6144 + d1 * 512 + d2, d3), <1x1>, memref<192x1x!ttcore.tile<32x32, f32>, #dram>, <interleaved>>
#ttnn_layout10 = #ttnn.ttnn_layout<(d0, d1, d2, d3) -> (d0 * 12672 + d1 * 1056 + d2, d3), <1x1>, memref<396x4x!ttcore.tile<32x32, bf16>, #dram>, <interleaved>>
module @SyncTensorsGraph.55 attributes {mhlo.cross_program_prefetches = [], mhlo.input_output_alias = [], mhlo.is_dynamic = false, mhlo.use_auto_spmd_partitioning = false, ttcore.meshes = #ttcore.meshes<[<"mesh" = 1x1>]>} {
  ttcore.device_module {
    builtin.module @SyncTensorsGraph.55 attributes {mhlo.cross_program_prefetches = [], mhlo.input_output_alias = [], mhlo.is_dynamic = false, mhlo.use_auto_spmd_partitioning = false, ttcore.meshes = #ttcore.meshes<[<"mesh" = 1x1>]>, ttcore.system_desc = #system_desc, ttnn.l1_const_eval_usage = 1024 : ui64} {
      ttcore.device @default_device = <workerGrid = #ttcore.grid<8x8, virt_to_physical_map = (d0, d1) -> (0, d0, d1), physical_to_virt_map = (d0, d1, d2) -> (d1, d2)>, dramGrid = #ttcore.grid<1x12>, l1Map = (d0, d1, d2)[s0] -> (0, d0, d1, d2 + s0), dramMap = (d0, d1, d2)[s0, s1, s2, s3, s4, s5, s6] -> (0, 0, (((d0 * s1) * (s2 * (s3 * s6)) + d1 * (s2 * (s3 * s6)) + d2) floordiv s4) mod 12, ((((d0 * s1) * (s2 * (s3 * s6)) + d1 * (s2 * (s3 * s6)) + d2) floordiv s4) floordiv 12) * s4 + ((d0 * s1) * (s2 * (s3 * s6)) + d1 * (s2 * (s3 * s6)) + d2) mod s4 + s5), meshShape = 1x1, chipIds = [0]> loc(#loc)
      func.func private @main_const_eval_0() -> tensor<1x1x1x1xf32, #ttnn_layout> attributes {tt.function_type = "const_eval"} {
        %0 = "ttnn.get_device"() <{mesh_offset = #ttnn<mesh_offset 0x0>, mesh_shape = #ttnn<mesh_shape 1x1>}> : () -> !ttnn.device loc(#loc)
        %1 = "ttnn.full"(%0) <{fill_value = 1.000000e+00 : f32, shape = #ttnn.shape<1x1x1x1>}> : (!ttnn.device) -> tensor<1x1x1x1xf32, #ttnn_layout> loc(#loc)
        return %1 : tensor<1x1x1x1xf32, #ttnn_layout> loc(#loc)
      } loc(#loc)
      func.func private @main_const_eval_1() -> tensor<1x1x1x1xf32, #ttnn_layout> attributes {tt.function_type = "const_eval"} {
        %0 = "ttnn.get_device"() <{mesh_offset = #ttnn<mesh_offset 0x0>, mesh_shape = #ttnn<mesh_shape 1x1>}> : () -> !ttnn.device loc(#loc)
        %1 = "ttnn.full"(%0) <{fill_value = 0.0883883461 : f32, shape = #ttnn.shape<1x1x1x1>}> : (!ttnn.device) -> tensor<1x1x1x1xf32, #ttnn_layout> loc(#loc)
        return %1 : tensor<1x1x1x1xf32, #ttnn_layout> loc(#loc)
      } loc(#loc)
      func.func @main(%arg0: tensor<1x1029x12x128xbf16, #ttnn_layout1> {ttcore.argument_type = #ttcore.argument_type<input>, ttcore.local_shape = #ttcore<local_shape local_shape = tensor<1x1029x12x128xbf16>>, ttcore.shard_status = #ttcore.shard_status<unsharded>, ttir.name = "arg2_1"} loc("p0.1"), %arg1: tensor<1x1029x12x128xbf16, #ttnn_layout1> {ttcore.argument_type = #ttcore.argument_type<input>, ttcore.local_shape = #ttcore<local_shape local_shape = tensor<1x1029x12x128xbf16>>, ttcore.shard_status = #ttcore.shard_status<unsharded>, ttir.name = "arg1_1"} loc("p1.7"), %arg2: tensor<1x512x12x128xbf16, #ttnn_layout2> {ttcore.argument_type = #ttcore.argument_type<input>, ttcore.local_shape = #ttcore<local_shape local_shape = tensor<1x512x12x128xbf16>>, ttcore.shard_status = #ttcore.shard_status<unsharded>, ttir.name = "arg0_1"} loc("p2.12")) -> (tensor<1x512x12x128xbf16, #ttnn_layout3> {ttcore.local_shape = #ttcore<local_shape local_shape = tensor<1x512x12x128xbf16>>, ttcore.shard_status = #ttcore.shard_status<presharded>}) attributes {tt.function_type = "forward_device"} {
        %0 = ttcore.load_cached(@main_const_eval_0, []) : () -> tensor<1x1x1x1xf32, #ttnn_layout> loc(#loc)
        %1 = ttcore.load_cached(@main_const_eval_1, []) : () -> tensor<1x1x1x1xf32, #ttnn_layout> loc(#loc)
        %2 = "ttnn.to_layout"(%arg2) : (tensor<1x512x12x128xbf16, #ttnn_layout2>) -> tensor<1x512x12x128xbf16, #ttnn_layout3> loc(#loc3)
        "ttnn.deallocate"(%arg2) <{force = false}> : (tensor<1x512x12x128xbf16, #ttnn_layout2>) -> () loc(#loc3)
        %3 = "ttnn.permute"(%2) <{permutation = array<i64: 0, 2, 1, 3>}> : (tensor<1x512x12x128xbf16, #ttnn_layout3>) -> tensor<1x12x512x128xbf16, #ttnn_layout4> loc(#loc4)
        "ttnn.deallocate"(%2) <{force = false}> : (tensor<1x512x12x128xbf16, #ttnn_layout3>) -> () loc(#loc4)
        %4 = "ttnn.to_layout"(%arg1) : (tensor<1x1029x12x128xbf16, #ttnn_layout1>) -> tensor<1x1029x12x128xbf16, #ttnn_layout5> loc(#loc2)
        "ttnn.deallocate"(%arg1) <{force = false}> : (tensor<1x1029x12x128xbf16, #ttnn_layout1>) -> () loc(#loc2)
        %5 = "ttnn.permute"(%4) <{permutation = array<i64: 0, 2, 3, 1>}> : (tensor<1x1029x12x128xbf16, #ttnn_layout5>) -> tensor<1x12x128x1029xbf16, #ttnn_layout6> loc(#loc5)
        "ttnn.deallocate"(%4) <{force = false}> : (tensor<1x1029x12x128xbf16, #ttnn_layout5>) -> () loc(#loc5)
        %6 = "ttnn.matmul"(%3, %5) <{compute_config = #ttnn.device_compute_kernel_config<math_fidelity = hifi4, fp32_dest_acc_en = true>, transpose_a = false, transpose_b = false}> : (tensor<1x12x512x128xbf16, #ttnn_layout4>, tensor<1x12x128x1029xbf16, #ttnn_layout6>) -> tensor<1x12x512x1029xbf16, #ttnn_layout7> loc(#loc6)
        "ttnn.deallocate"(%5) <{force = false}> : (tensor<1x12x128x1029xbf16, #ttnn_layout6>) -> () loc(#loc6)
        "ttnn.deallocate"(%3) <{force = false}> : (tensor<1x12x512x128xbf16, #ttnn_layout4>) -> () loc(#loc6)
        %7 = "ttnn.typecast"(%6) : (tensor<1x12x512x1029xbf16, #ttnn_layout7>) -> tensor<1x12x512x1029xf32, #ttnn_layout8> loc(#loc7)
        "ttnn.deallocate"(%6) <{force = false}> : (tensor<1x12x512x1029xbf16, #ttnn_layout7>) -> () loc(#loc7)
        %8 = "ttnn.multiply"(%7, %1) : (tensor<1x12x512x1029xf32, #ttnn_layout8>, tensor<1x1x1x1xf32, #ttnn_layout>) -> tensor<1x12x512x1029xf32, #ttnn_layout8> loc(#loc8)
        "ttnn.deallocate"(%7) <{force = false}> : (tensor<1x12x512x1029xf32, #ttnn_layout8>) -> () loc(#loc8)
        "ttnn.deallocate"(%1) <{force = false}> : (tensor<1x1x1x1xf32, #ttnn_layout>) -> () loc(#loc8)
        %9 = "ttnn.max"(%8) <{compute_config = #ttnn.device_compute_kernel_config<math_fidelity = hifi4, fp32_dest_acc_en = true>, dim_arg = [3 : i32], keep_dim = true}> : (tensor<1x12x512x1029xf32, #ttnn_layout8>) -> tensor<1x12x512x1xf32, #ttnn_layout9> loc(#loc9)
        %10 = "ttnn.subtract"(%8, %9) : (tensor<1x12x512x1029xf32, #ttnn_layout8>, tensor<1x12x512x1xf32, #ttnn_layout9>) -> tensor<1x12x512x1029xf32, #ttnn_layout8> loc(#loc10)
        "ttnn.deallocate"(%9) <{force = false}> : (tensor<1x12x512x1xf32, #ttnn_layout9>) -> () loc(#loc10)
        "ttnn.deallocate"(%8) <{force = false}> : (tensor<1x12x512x1029xf32, #ttnn_layout8>) -> () loc(#loc10)
        %11 = "ttnn.exp"(%10) : (tensor<1x12x512x1029xf32, #ttnn_layout8>) -> tensor<1x12x512x1029xf32, #ttnn_layout8> loc(#loc11)
        "ttnn.deallocate"(%10) <{force = false}> : (tensor<1x12x512x1029xf32, #ttnn_layout8>) -> () loc(#loc11)
        %12 = "ttnn.sum"(%11) <{compute_config = #ttnn.device_compute_kernel_config<math_fidelity = hifi4, fp32_dest_acc_en = true>, dim_arg = [3 : i32], keep_dim = true}> : (tensor<1x12x512x1029xf32, #ttnn_layout8>) -> tensor<1x12x512x1xf32, #ttnn_layout9> loc(#loc12)
        %13 = "ttnn.divide"(%0, %12) : (tensor<1x1x1x1xf32, #ttnn_layout>, tensor<1x12x512x1xf32, #ttnn_layout9>) -> tensor<1x12x512x1xf32, #ttnn_layout9> loc(#loc13)
        "ttnn.deallocate"(%12) <{force = false}> : (tensor<1x12x512x1xf32, #ttnn_layout9>) -> () loc(#loc13)
        "ttnn.deallocate"(%0) <{force = false}> : (tensor<1x1x1x1xf32, #ttnn_layout>) -> () loc(#loc13)
        %14 = "ttnn.multiply"(%11, %13) : (tensor<1x12x512x1029xf32, #ttnn_layout8>, tensor<1x12x512x1xf32, #ttnn_layout9>) -> tensor<1x12x512x1029xf32, #ttnn_layout8> loc(#loc14)
        "ttnn.deallocate"(%13) <{force = false}> : (tensor<1x12x512x1xf32, #ttnn_layout9>) -> () loc(#loc14)
        "ttnn.deallocate"(%11) <{force = false}> : (tensor<1x12x512x1029xf32, #ttnn_layout8>) -> () loc(#loc14)
        %15 = "ttnn.typecast"(%14) : (tensor<1x12x512x1029xf32, #ttnn_layout8>) -> tensor<1x12x512x1029xbf16, #ttnn_layout7> loc(#loc15)
        "ttnn.deallocate"(%14) <{force = false}> : (tensor<1x12x512x1029xf32, #ttnn_layout8>) -> () loc(#loc15)
        %16 = "ttnn.to_layout"(%arg0) : (tensor<1x1029x12x128xbf16, #ttnn_layout1>) -> tensor<1x1029x12x128xbf16, #ttnn_layout5> loc(#loc1)
        "ttnn.deallocate"(%arg0) <{force = false}> : (tensor<1x1029x12x128xbf16, #ttnn_layout1>) -> () loc(#loc1)
        %17 = "ttnn.permute"(%16) <{permutation = array<i64: 0, 2, 1, 3>}> : (tensor<1x1029x12x128xbf16, #ttnn_layout5>) -> tensor<1x12x1029x128xbf16, #ttnn_layout10> loc(#loc16)
        "ttnn.deallocate"(%16) <{force = false}> : (tensor<1x1029x12x128xbf16, #ttnn_layout5>) -> () loc(#loc16)
        %18 = "ttnn.matmul"(%15, %17) <{compute_config = #ttnn.device_compute_kernel_config<math_fidelity = hifi4, fp32_dest_acc_en = true>, transpose_a = false, transpose_b = false}> : (tensor<1x12x512x1029xbf16, #ttnn_layout7>, tensor<1x12x1029x128xbf16, #ttnn_layout10>) -> tensor<1x12x512x128xbf16, #ttnn_layout4> loc(#loc17)
        "ttnn.deallocate"(%17) <{force = false}> : (tensor<1x12x1029x128xbf16, #ttnn_layout10>) -> () loc(#loc17)
        "ttnn.deallocate"(%15) <{force = false}> : (tensor<1x12x512x1029xbf16, #ttnn_layout7>) -> () loc(#loc17)
        %19 = "ttnn.permute"(%18) <{permutation = array<i64: 0, 2, 1, 3>}> : (tensor<1x12x512x128xbf16, #ttnn_layout4>) -> tensor<1x512x12x128xbf16, #ttnn_layout3> loc(#loc18)
        "ttnn.deallocate"(%18) <{force = false}> : (tensor<1x12x512x128xbf16, #ttnn_layout4>) -> () loc(#loc18)
        return %19 : tensor<1x512x12x128xbf16, #ttnn_layout3> loc(#loc)
      } loc(#loc)
    } loc(#loc)
  } loc(#loc)
} loc(#loc)
#loc = loc(unknown)
#loc4 = loc("transpose.14")
#loc5 = loc("transpose.10")
#loc6 = loc("dot.16")
#loc7 = loc("convert.18")
#loc8 = loc("multiply.20")
#loc9 = loc("reduce.27")
#loc10 = loc("subtract.33")
#loc11 = loc("exponential.34")
#loc12 = loc("reduce.41")
#loc13 = loc("divide.45")
#loc14 = loc("multiply.48")
#loc15 = loc("convert.49")
#loc16 = loc("transpose.3")
#loc17 = loc("dot.51")
#loc18 = loc("transpose.53")
